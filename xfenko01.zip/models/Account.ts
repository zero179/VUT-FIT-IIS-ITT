export interface IAccount {
    email: string
    password?: string
}