import {IUserInput} from "./UserInput";

export interface IUser extends IUserInput {
    id: string
}