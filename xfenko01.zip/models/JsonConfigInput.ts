export interface IJsonConfigInput {
    json: string
    userId: string
}
