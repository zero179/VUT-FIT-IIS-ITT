export interface IRoleInput {
    name: string
    description?: string
}
