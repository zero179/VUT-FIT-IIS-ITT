export interface IPaging {
    pageSize: number
    pageNumber: number
    totalElements: number
}