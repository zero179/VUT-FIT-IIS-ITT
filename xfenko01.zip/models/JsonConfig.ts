import {IJsonConfigInput} from "./JsonConfigInput";

export interface IJsonConfig extends IJsonConfigInput {
    id: string
}