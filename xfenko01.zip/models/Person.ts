export interface IPerson {
    firstName: string
    lastName: string
    phoneCountryPrefix: string
    phoneNumber: string
}