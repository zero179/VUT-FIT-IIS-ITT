import {IRoleInput} from "./RoleInput";

export interface IRole extends IRoleInput {
    id: string
}