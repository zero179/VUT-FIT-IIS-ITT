interface Context {
    userId?: string
    roles?: string
}

export default Context